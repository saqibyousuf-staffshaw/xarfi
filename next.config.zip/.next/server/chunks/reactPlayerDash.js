"use strict";exports.id=395,exports.ids=[395],exports.modules={2949:(t,e,i)=>{i.d(e,{lB:()=>d});let s=["abort","canplay","canplaythrough","durationchange","emptied","encrypted","ended","error","loadeddata","loadedmetadata","loadstart","pause","play","playing","progress","ratechange","seeked","seeking","stalled","suspend","timeupdate","volumechange","waiting","waitingforkey","resize","enterpictureinpicture","leavepictureinpicture","webkitbeginfullscreen","webkitendfullscreen","webkitpresentationmodechanged"],a=["autopictureinpicture","disablepictureinpicture","disableremoteplayback","autoplay","controls","controlslist","crossorigin","loop","muted","playsinline","poster","preload","src"];function n(t){return`
    <style>
      :host {
        display: inline-flex;
        line-height: 0;
        flex-direction: column;
        justify-content: end;
      }

      audio {
        width: 100%;
      }
    </style>
    <slot name="media">
      <audio${l(t)}></audio>
    </slot>
    <slot></slot>
  `}function r(t){return`
    <style>
      :host {
        display: inline-block;
        line-height: 0;
      }

      video {
        max-width: 100%;
        max-height: 100%;
        min-width: 100%;
        min-height: 100%;
        object-fit: var(--media-object-fit, contain);
        object-position: var(--media-object-position, 50% 50%);
      }

      video::-webkit-media-text-track-container {
        transform: var(--media-webkit-text-track-transform);
        transition: var(--media-webkit-text-track-transition);
      }
    </style>
    <slot name="media">
      <video${l(t)}></video>
    </slot>
    <slot></slot>
  `}function o(t,{tag:e,is:i}){let o=globalThis.document?.createElement?.(e,{is:i}),l=o?function(t){let e=[];for(let i=Object.getPrototypeOf(t);i&&i!==HTMLElement.prototype;i=Object.getPrototypeOf(i)){let t=Object.getOwnPropertyNames(i);e.push(...t)}return e}(o):[];return class d extends t{static getTemplateHTML=e.endsWith("audio")?n:r;static shadowRootOptions={mode:"open"};static Events=s;static #t=!1;static get observedAttributes(){return d.#e(),[...o?.constructor?.observedAttributes??[],...a]}static #e(){if(this.#t)return;this.#t=!0;let t=new Set(this.observedAttributes);for(let e of(t.delete("muted"),l))if(!(e in this.prototype))if("function"==typeof o[e])this.prototype[e]=function(...t){return this.#i(),(()=>{if(this.call)return this.call(e,...t);let i=this.nativeEl?.[e];return i?.apply(this.nativeEl,t)})()};else{let i={get(){this.#i();let i=e.toLowerCase();if(t.has(i)){let t=this.getAttribute(i);return null!==t&&(""===t||t)}return this.get?.(e)??this.nativeEl?.[e]}};e!==e.toUpperCase()&&(i.set=function(i){this.#i();let s=e.toLowerCase();return t.has(s)?void(!0===i||!1===i||null==i?this.toggleAttribute(s,!!i):this.setAttribute(s,i)):this.set?void this.set(e,i):void(this.nativeEl&&(this.nativeEl[e]=i))}),Object.defineProperty(this.prototype,e,i)}}#s=!1;#a=null;#n=new Map;#r;get;set;call;get nativeEl(){return this.#i(),this.#a??this.querySelector(":scope > [slot=media]")??this.querySelector(e)??this.shadowRoot?.querySelector(e)??null}set nativeEl(t){this.#a=t}get defaultMuted(){return this.hasAttribute("muted")}set defaultMuted(t){this.toggleAttribute("muted",t)}get src(){return this.getAttribute("src")}set src(t){this.setAttribute("src",`${t}`)}get preload(){return this.getAttribute("preload")??this.nativeEl?.preload}set preload(t){this.setAttribute("preload",`${t}`)}#i(){this.#s||(this.#s=!0,this.init())}init(){if(!this.shadowRoot){this.attachShadow({mode:"open"});let t=function(t){let e={};for(let i of t)e[i.name]=i.value;return e}(this.attributes);i&&(t.is=i),e&&(t.part=e),this.shadowRoot.innerHTML=this.constructor.getTemplateHTML(t)}for(let t of(this.nativeEl.muted=this.hasAttribute("muted"),l))this.#o(t);for(let t of(this.#r=new MutationObserver(this.#l.bind(this)),this.shadowRoot.addEventListener("slotchange",()=>this.#d()),this.#d(),this.constructor.Events))this.shadowRoot.addEventListener(t,this,!0)}handleEvent(t){t.target===this.nativeEl&&this.dispatchEvent(new CustomEvent(t.type,{detail:t.detail}))}#d(){let t=new Map(this.#n),e=this.shadowRoot?.querySelector("slot:not([name])");(e?.assignedElements({flatten:!0}).filter(t=>["track","source"].includes(t.localName))).forEach(e=>{t.delete(e);let i=this.#n.get(e);i||(i=e.cloneNode(),this.#n.set(e,i),this.#r?.observe(e,{attributes:!0})),this.nativeEl?.append(i),this.#h(i)}),t.forEach((t,e)=>{t.remove(),this.#n.delete(e)})}#l(t){for(let e of t)if("attributes"===e.type){let{target:t,attributeName:i}=e,s=this.#n.get(t);s&&i&&(s.setAttribute(i,t.getAttribute(i)??""),this.#h(s))}}#h(t){t&&"track"===t.localName&&t.default&&("chapters"===t.kind||"metadata"===t.kind)&&"disabled"===t.track.mode&&(t.track.mode="hidden")}#o(t){if(Object.prototype.hasOwnProperty.call(this,t)){let e=this[t];delete this[t],this[t]=e}}attributeChangedCallback(t,e,i){this.#i(),this.#u(t,e,i)}#u(t,e,i){!["id","class"].includes(t)&&(!d.observedAttributes.includes(t)&&this.constructor.observedAttributes.includes(t)||(null===i?this.nativeEl?.removeAttribute(t):this.nativeEl?.getAttribute(t)!==i&&this.nativeEl?.setAttribute(t,i)))}connectedCallback(){this.#i()}}}function l(t){let e="";for(let i in t){if(!a.includes(i))continue;let s=t[i];""===s?e+=` ${i}`:e+=` ${i}="${s}"`}return e}let d=o(globalThis.HTMLElement??class{},{tag:"video"});o(globalThis.HTMLElement??class{},{tag:"audio"})},8691:(t,e,i)=>{i.r(e),i.d(e,{default:()=>d});var s=i(3210),a=i(2949);class n extends a.lB{static shadowRootOptions={...a.lB.shadowRootOptions};static getTemplateHTML=t=>{let{src:e,...i}=t;return a.lB.getTemplateHTML(i)};#c;attributeChangedCallback(t,e,i){"src"!==t&&super.attributeChangedCallback(t,e,i),"src"===t&&e!=i&&this.load()}async load(){if(this.#c)this.api.attachSource(this.src);else{this.#c=!0;let t=await i.e(828).then(i.bind(i,5447));this.api=t.MediaPlayer().create(),this.api.initialize(this.nativeEl,this.src,this.autoplay)}}}globalThis.customElements&&!globalThis.customElements.get("dash-video")&&globalThis.customElements.define("dash-video",n);var r=new Set(["style","children","ref","key","suppressContentEditableWarning","suppressHydrationWarning","dangerouslySetInnerHTML"]),o={className:"class",htmlFor:"for"};function l(t){return"boolean"==typeof t?t?"":void 0:"function"==typeof t?void 0:"object"!=typeof t||null===t?t:void 0}var d=function({react:t,tagName:e,elementClass:i,events:s,displayName:a,defaultProps:n,toAttributeName:d=function(t){return t.toLowerCase()},toAttributeValue:h=l}){let u=Number.parseInt(t.version)>=19,c=t.forwardRef((s,a)=>{var c,p;let f=t.useRef(null);t.useRef(new Map);let b={},m={},g={},v={};for(let[t,e]of Object.entries(s)){if(r.has(t)){g[t]=e;continue}let s=d(o[t]??t);if(t in i.prototype&&!(t in((null==(c=globalThis.HTMLElement)?void 0:c.prototype)??{}))&&!(null==(p=i.observedAttributes)?void 0:p.some(t=>t===s))){v[t]=e;continue}if(t.startsWith("on")){b[t]=e;continue}let a=h(e);s&&null!=a&&(m[s]=String(a),u||(g[s]=a)),s&&u&&(a!==l(e)?g[s]=a:g[s]=e)}if((null==i?void 0:i.getTemplateHTML)&&(null==i?void 0:i.shadowRootOptions)){let{mode:e,delegatesFocus:a}=i.shadowRootOptions;g.children=[t.createElement("template",{shadowrootmode:e,shadowrootdelegatesfocus:a,dangerouslySetInnerHTML:{__html:i.getTemplateHTML(m,s)}}),g.children]}return t.createElement(e,{...n,...g,ref:t.useCallback(t=>{f.current=t,"function"==typeof a?a(t):null!==a&&(a.current=t)},[a])})});return c.displayName=a??i.name,c}({react:s,tagName:"dash-video",elementClass:n})}};